# UPI Sonic – Android project

ही पहिली Android source-code आवृत्ती आहे. हा APK नाही; APK तयार करण्यासाठी Android Studio किंवा GitHub Actions वापरा.

## Android Studio मधून APK
1. ZIP extract करा.
2. Android Studio मध्ये `UPI_Sonic_Android` folder उघडा.
3. Gradle sync पूर्ण होऊ द्या.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. APK `app/build/outputs/apk/debug/app-debug.apk` येथे मिळेल.
6. फोनवर APK install करा आणि Settings मधून UPI Sonic साठी Notification Access परवानगी सुरू करा.

## GitHub Actions मधून
Project GitHub repository मध्ये push करा आणि Actions > Build Android APK > Run workflow निवडा. तयार APK हा workflow artifact म्हणून download करता येईल.

## महत्त्वाच्या मर्यादा
- हे अॅप Android notification वाचते; बँक खात्याशी जोडलेले नाही.
- notification मजकूर/रक्कम प्रत्येक UPI अॅप व फोननुसार बदलू शकते. त्यामुळे सर्व UPI apps वर अचूक काम करेल याची हमी नाही.
- ही आवृत्ती केवळ सामान्य UPI payment notifications मधील received/credited मजकूर आणि रक्कम शोधते. बँक क्रेडिटची स्वतंत्र पडताळणी करत नाही.
- Notification Access दिल्यास अॅपला इतर notifications देखील तांत्रिकदृष्ट्या दिसू शकतात. ही परवानगी फक्त तुम्हाला विश्वास असलेल्या अॅपलाच द्या.
- Android battery optimization मुळे background announcements थांबू शकतात.
- मराठी TTS आवाज फोनमध्ये उपलब्ध असणे आवश्यक आहे.
