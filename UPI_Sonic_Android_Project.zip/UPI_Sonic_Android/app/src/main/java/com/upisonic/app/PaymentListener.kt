package com.upisonic.app

import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class PaymentListener : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    private val ready = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("mr", "IN"))
                ready.set(result != TextToSpeech.LANG_MISSING_DATA &&
                          result != TextToSpeech.LANG_NOT_SUPPORTED)
                tts?.setSpeechRate(0.95f)
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName.lowercase(Locale.ROOT)
        if (pkg == packageName || !isLikelyUpiPackage(pkg)) return

        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val text = listOf(title, body, big).joinToString(" ").trim()
        if (text.isBlank() || !looksLikeReceivedPayment(text)) return

        val amount = Regex("""(?i)(?:₹|rs\.?|inr)\s*([0-9,]+(?:\.[0-9]{1,2})?)|([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:rupees|rs\.?|inr)""")
            .find(text)?.let { it.groupValues[1].ifBlank { it.groupValues[2] } } ?: return

        val key = "${sbn.key}_${sbn.postTime}"
        val prefs = getSharedPreferences("upi_sonic", MODE_PRIVATE)
        if (prefs.getString("last_key", "") == key) return
        prefs.edit().putString("last_key", key).apply()

        val source = when {
            pkg.contains("google") -> "Google Pay"
            pkg.contains("phonepe") -> "PhonePe"
            pkg.contains("paytm") -> "Paytm"
            pkg.contains("bhim") -> "BHIM"
            else -> "UPI"
        }
        val amountSpoken = amount.replace(",", "")
        val spoken = "तुमच्या खात्यात $amountSpoken रुपये जमा झाले."
        if (ready.get()) tts?.speak(spoken, TextToSpeech.QUEUE_ADD, null, key)

        val stamp = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("mr", "IN")).format(Date(sbn.postTime))
        val old = prefs.getString("history", "") ?: ""
        val row = "$stamp • $source • ₹$amount"
        val updated = (listOf(row) + old.lines().filter { it.isNotBlank() }).take(30).joinToString("\n")
        val dayKey = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(sbn.postTime))
        val previousTotal = if (prefs.getString("total_day", "") == dayKey) prefs.getFloat("daily_total", 0f) else 0f
        val newTotal = previousTotal + amount.replace(",", "").toFloatOrNull().orEmptyZero()
        prefs.edit().putString("history", updated).putString("total_day", dayKey)
            .putFloat("daily_total", newTotal).apply()
    }

    private fun isLikelyUpiPackage(pkg: String): Boolean {
        // Common UPI app package identifiers; unknown apps are deliberately excluded in v1.
        return listOf("google", "phonepe", "paytm", "bhim", "amazon", "mobikwik",
            "cred", "freecharge", "super.money", "slice").any { pkg.contains(it) }
    }

    private fun looksLikeReceivedPayment(text: String): Boolean {
        val t = text.lowercase(Locale.ROOT)
        val positive = listOf("received", "credited", " जमा", "जमा", "प्राप्त", "got", "payment from", " पैसे मिले")
        val negative = listOf("sent", "debited", "paid to", "payment successful", "payment pending",
            "failed", "declined", "request", "collect", "reminder")
        return positive.any { t.contains(it) } && negative.none { t.contains(it) }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        fun speakTest(context: Context) {
            lateinit var engine: TextToSpeech
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val languageResult = engine.setLanguage(Locale("mr", "IN"))
                    if (languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                        engine.speak("UPI Sonic तयार आहे. मराठी आवाज सुरू आहे.", TextToSpeech.QUEUE_FLUSH, null, "test")
                    }
                }
            }
        }
    }
}

private fun Float?.orEmptyZero(): Float = this ?: 0f
