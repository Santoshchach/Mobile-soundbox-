package com.upisonic.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("upi_sonic", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    private lateinit var root: LinearLayout

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 24)
            setBackgroundColor(Color.rgb(246, 249, 247))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "🔊 UPI Sonic"
            textSize = 30f
            setTextColor(Color.rgb(20, 65, 45))
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(label("तुमचा वैयक्तिक UPI साउंडबॉक्स", 17f, true))
        root.addView(label("Merchant account आवश्यक नाही", 14f, false))

        val enabled = isNotificationAccessEnabled()
        val status = label(
            if (enabled) "● सूचना परवानगी सुरू आहे" else "● सूचना परवानगी बंद आहे",
            16f, true
        )
        status.setTextColor(if (enabled) Color.rgb(20, 130, 70) else Color.rgb(190, 80, 35))
        status.setPadding(0, 28, 0, 12)
        root.addView(status)

        val grant = Button(this).apply {
            text = if (enabled) "सूचना सेटिंग्ज उघडा" else "Notification Access सुरू करा"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        root.addView(grant, matchWrap())

        root.addView(label("आवाजाची भाषा", 18f, true).apply { setPadding(0, 28, 0, 8) })
        root.addView(label("मराठी (डिफॉल्ट)", 16f, false))

        root.addView(label("आवाजाची पातळी", 18f, true).apply { setPadding(0, 20, 0, 8) })
        val volume = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("volume", 85)
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    prefs.edit().putInt("volume", progress).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(volume, matchWrap())

        val test = Button(this).apply {
            text = "मराठी आवाज तपासा"
            setOnClickListener {
                PaymentListener.speakTest(this@MainActivity)
            }
        }
        root.addView(test, matchWrap())

        root.addView(label("आजची एकूण प्राप्त रक्कम: ₹${String.format(java.util.Locale.US, "%.2f", prefs.getFloat("daily_total", 0f))}", 18f, true).apply { setPadding(0, 28, 0, 8) })
        root.addView(label("आजच्या नोंदी", 20f, true).apply { setPadding(0, 12, 0, 8) })
        val history = prefs.getString("history", "") ?: ""
        root.addView(label(if (history.isBlank()) "अजून कोणतीही पेमेंट सूचना मिळालेली नाही." else history, 14f, false))

        root.addView(label(
            "टीप: हे अॅप UPI अॅपच्या notification वरून रक्कम वाचते. बँक खात्यातील प्रत्यक्ष जमा स्वतंत्रपणे तपासा. बनावट किंवा अपूर्ण सूचना आल्यास आवाज चुकीचा असू शकतो.",
            13f, false
        ).apply { setPadding(0, 28, 0, 8) })
    }

    private fun isNotificationAccessEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    private fun label(textValue: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(Color.rgb(35, 48, 42))
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 5, 0, 5)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
